import * as SQLite from 'expo-sqlite';

let db = null;

export async function initDatabase() {
  if (db) return db;

  db = await SQLite.openDatabaseAsync('falashi.db');

  await db.execAsync(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS decks (
      id TEXT PRIMARY KEY NOT NULL,
      title TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cards (
      id TEXT PRIMARY KEY NOT NULL,
      deck_id TEXT NOT NULL,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (deck_id) REFERENCES decks(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS wallet (
      id INTEGER PRIMARY KEY NOT NULL,
      coins INTEGER NOT NULL DEFAULT 0
    );

    INSERT OR IGNORE INTO wallet (id, coins) VALUES (1, 0);

    CREATE TABLE IF NOT EXISTS ranking (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      deck_title TEXT NOT NULL,
      score INTEGER NOT NULL,
      total INTEGER NOT NULL,
      played_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS owned_cosmetics (
      cosmetic_id TEXT PRIMARY KEY NOT NULL,
      bought_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS profile (
      id INTEGER PRIMARY KEY NOT NULL,
      player_name TEXT NOT NULL DEFAULT 'Jogador'
    );

    INSERT OR IGNORE INTO profile (id, player_name) VALUES (1, 'Jogador');
  `);

  // A tabela "equipped" é tratada separadamente das demais, porque versões antigas do app
  // criaram esquemas diferentes para ela (ex: sem a coluna "cosmetic_type"). Se a criássemos
  // junto do bloco acima com "CREATE TABLE IF NOT EXISTS", um dispositivo com a tabela antiga
  // continuaria com o esquema errado e o INSERT seguinte quebraria o app inteiro.
  try {
    const equippedInfo = await db.getAllAsync('PRAGMA table_info(equipped)');
    const hasCosmeticType = equippedInfo.some((col) => col.name === 'cosmetic_type');

    if (equippedInfo.length === 0) {
      // Tabela ainda não existe: cria já no formato correto.
      await db.execAsync(`
        CREATE TABLE equipped (
          cosmetic_type TEXT PRIMARY KEY NOT NULL,
          cosmetic_id TEXT NOT NULL
        );
      `);
    } else if (!hasCosmeticType) {
      // Tabela existe num formato antigo (sem a coluna "cosmetic_type").
      // Tenta preservar o avatar equipado antes de recriar a tabela no formato novo.
      let previousAvatar = 'avatar_default';
      try {
        const oldRow = await db.getFirstAsync('SELECT cosmetic_id FROM equipped LIMIT 1');
        if (oldRow?.cosmetic_id?.startsWith('avatar_')) {
          previousAvatar = oldRow.cosmetic_id;
        }
      } catch (e) {
        // Ignora: se não conseguir ler o valor antigo, segue com o padrão.
      }
      await db.execAsync('DROP TABLE equipped;');
      await db.execAsync(`
        CREATE TABLE equipped (
          cosmetic_type TEXT PRIMARY KEY NOT NULL,
          cosmetic_id TEXT NOT NULL
        );
      `);
      await db.runAsync(
        'INSERT OR IGNORE INTO equipped (cosmetic_type, cosmetic_id) VALUES (?, ?)',
        'avatar', previousAvatar
      );
    }
  } catch (err) {
    console.warn('[database] Erro ao preparar tabela equipped:', err.message);
  }

  // Garante que sempre exista um valor padrão equipado para cada tipo de cosmético.
  await db.runAsync(
    "INSERT OR IGNORE INTO equipped (cosmetic_type, cosmetic_id) VALUES ('avatar', 'avatar_default')"
  );
  await db.runAsync(
    "INSERT OR IGNORE INTO equipped (cosmetic_type, cosmetic_id) VALUES ('deck', 'deck_default')"
  );

  return db;
}

function getDb() {
  if (!db) throw new Error('Banco não inicializado. Chame initDatabase() antes.');
  return db;
}

// ---------- COSMÉTICOS ----------

export async function fetchOwnedCosmetics() {
  const database = getDb();
  const rows = await database.getAllAsync('SELECT cosmetic_id FROM owned_cosmetics');
  return rows.map((r) => r.cosmetic_id);
}

export async function buyCosmetic(cosmeticId) {
  const database = getDb();
  await database.runAsync(
    'INSERT OR IGNORE INTO owned_cosmetics (cosmetic_id, bought_at) VALUES (?, ?)',
    cosmeticId, Date.now()
  );
}

export async function fetchEquipped() {
  const database = getDb();
  const rows = await database.getAllAsync('SELECT cosmetic_type, cosmetic_id FROM equipped');
  const result = { avatar: 'avatar_default', deck: 'deck_default' };
  rows.forEach((r) => { result[r.cosmetic_type] = r.cosmetic_id; });
  return result;
}

export async function equipCosmetic(cosmeticType, cosmeticId) {
  const database = getDb();
  await database.runAsync(
    'INSERT INTO equipped (cosmetic_type, cosmetic_id) VALUES (?, ?) ON CONFLICT(cosmetic_type) DO UPDATE SET cosmetic_id = ?',
    cosmeticType, cosmeticId, cosmeticId
  );
}

// ---------- PERFIL ----------

export async function fetchPlayerName() {
  const database = getDb();
  const row = await database.getFirstAsync('SELECT player_name FROM profile WHERE id = 1');
  return row?.player_name ?? 'Jogador';
}

export async function savePlayerName(name) {
  const database = getDb();
  await database.runAsync('UPDATE profile SET player_name = ? WHERE id = 1', name);
}

// ---------- DECKS ----------

export async function fetchAllDecks() {
  const database = getDb();
  const decks = await database.getAllAsync('SELECT * FROM decks ORDER BY created_at ASC');
  const cards = await database.getAllAsync('SELECT * FROM cards ORDER BY created_at ASC');
  return decks.map((deck) => ({
    id: deck.id,
    title: deck.title,
    cards: cards
      .filter((c) => c.deck_id === deck.id)
      .map((c) => ({ id: c.id, question: c.question, answer: c.answer })),
  }));
}

export async function insertDeck(id, title) {
  const database = getDb();
  await database.runAsync(
    'INSERT INTO decks (id, title, created_at) VALUES (?, ?, ?)',
    id, title, Date.now()
  );
}

export async function deleteDeck(id) {
  const database = getDb();
  await database.runAsync('DELETE FROM cards WHERE deck_id = ?', id);
  await database.runAsync('DELETE FROM decks WHERE id = ?', id);
}

// ---------- CARDS ----------

export async function insertCard(id, deckId, question, answer) {
  const database = getDb();
  await database.runAsync(
    'INSERT INTO cards (id, deck_id, question, answer, created_at) VALUES (?, ?, ?, ?, ?)',
    id, deckId, question, answer, Date.now()
  );
}

export async function deleteCard(id) {
  const database = getDb();
  await database.runAsync('DELETE FROM cards WHERE id = ?', id);
}

// ---------- WALLET ----------

export async function fetchCoins() {
  const database = getDb();
  const row = await database.getFirstAsync('SELECT coins FROM wallet WHERE id = 1');
  return row?.coins ?? 0;
}

export async function addCoins(amount) {
  const database = getDb();
  await database.runAsync('UPDATE wallet SET coins = coins + ? WHERE id = 1', amount);
  const row = await database.getFirstAsync('SELECT coins FROM wallet WHERE id = 1');
  return row?.coins ?? 0;
}

// ---------- RANKING ----------

export async function initRankingTable() {
  const database = getDb();
  await database.execAsync(`
    CREATE TABLE IF NOT EXISTS ranking (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      deck_title TEXT NOT NULL,
      score INTEGER NOT NULL,
      total INTEGER NOT NULL,
      played_at INTEGER NOT NULL
    );
  `);
}

export async function insertScore(deckTitle, score, total) {
  const database = getDb();
  await database.runAsync(
    'INSERT INTO ranking (deck_title, score, total, played_at) VALUES (?, ?, ?, ?)',
    deckTitle, score, total, Date.now()
  );
}

export async function fetchTopScores() {
  const database = getDb();
  return await database.getAllAsync(
    'SELECT * FROM ranking ORDER BY score DESC, played_at DESC LIMIT 10'
  );
}
